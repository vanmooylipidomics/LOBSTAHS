## ---- eval = FALSE-------------------------------------------------------
#  source("http://bioconductor.org/biocLite.R")
#  biocLite("CAMERA")
#  biocLite("xcms")

## ---- eval = FALSE-------------------------------------------------------
#  install.packages("devtools")

## ---- eval = FALSE-------------------------------------------------------
#  library("devtools")
#  install_github("vanmooylipidomics/LOBSTAHS")

## ---- eval = FALSE-------------------------------------------------------
#  ## install dataset 'PtH2O2lipids'
#  ## see LOBSTAHS documentation for examples
#  
#  install_github("vanmooylipidomics/PtH2O2lipids")

## ---- eval = FALSE-------------------------------------------------------
#  system(paste("msconvert Exactive_data.raw --mzXML --filter \"peakPicking true 1-\" -o mzXML_ms1_two_mode -v"))

## ---- eval = FALSE-------------------------------------------------------
#  system(paste("msconvert mzXML_ms1_two_mode/Exactive_data.mzXML --mzXML --filter \"polarity positive\" -o mzXML_ms1_pos_mode -v"))
#  system(paste("msconvert mzXML_ms1_two_mode/Exactive_data.mzXML --mzXML --filter \"polarity negative\" -o mzXML_ms1_neg_mode -v"))

## ---- warning = FALSE, message = FALSE, eval = FALSE---------------------
#  library(PtH2O2lipids)
#  ptH2O2lipids$xsAnnotate@xcmsSet
#  #> An "xcmsSet" object with 16 samples
#  #>
#  #> Time range: -1.1-1742.4 seconds (0-29 minutes)
#  #> Mass range: 100.0397-1499.3326 m/z
#  #> Peaks: 340991 (about 21312 per sample)
#  #> Peak Groups: 18314
#  #> Sample classes: 0_uM_H2O2, 150_uM_H2O2, 30_uM_H2O2
#  #>
#  #> Profile settings: method = bin
#  #>                   step = 0.001
#  #>
#  #> Memory usage: 64.5 MB

## ---- warning = FALSE, message = FALSE, eval = FALSE---------------------
#  library(xcms)
#  library(CAMERA)
#  library(LOBSTAHS)
#  
#  # first, a necessary workaround to avoid a import error; see
#  # https://support.bioconductor.org/p/69414/
#  
#  imports = parent.env(getNamespace("CAMERA"))
#  unlockBinding("groups", imports)
#  imports[["groups"]] = xcms::groups
#  lockBinding("groups", imports)
#  
#  # create annotated xset using wrapper annotate(), allowing us to perform all
#  # CAMERA tasks at once
#  
#  xsA = annotate(ptH2O2lipids$xsAnnotate@xcmsSet,
#  
#                 quick=FALSE,
#                 sample=NA, # use all samples
#                 nSlaves=1, # set to number of available cores or processors if
#                            # > 1
#  
#                 # group FWHM settings (defaults)
#  
#                 sigma=6,
#                 perfwhm=0.6,
#  
#                 # groupCorr settings (defaults)
#  
#                 cor_eic_th=0.75,
#                 graphMethod="hcs",
#                 pval=0.05,
#                 calcCiS=TRUE,
#                 calcIso=TRUE,
#                 calcCaS=FALSE,
#  
#                 # findIsotopes settings
#  
#                 maxcharge=4,
#                 maxiso=4,
#                 minfrac=0.5,
#  
#                 # adduct annotation settings
#  
#                 psg_list=NULL,
#                 rules=NULL,
#                 polarity="positive", # the PtH2O2lipids xcmsSet contains
#                                      # positive-mode data
#                 multiplier=3,
#                 max_peaks=100,
#  
#                 # common to multiple tasks
#  
#                 intval="into",
#                 ppm=2.5,
#                 mzabs=0.0015
#  
#                 )
#  #> Start grouping after retention time.
#  #> Created 113 pseudospectra.
#  #> Generating peak matrix!
#  #> Run isotope peak annotation
#  #>  % finished: 10  20  30  40  50  60  70  80  90  100
#  #> Found isotopes: 5692
#  #> Start grouping after correlation.
#  #> Generating EIC's ..
#  #>
#  #> Calculating peak correlations in 113 Groups...
#  #>  % finished: 10  20  30  40  50  60  70  80  90  100
#  #>
#  #> Calculating isotope assignments in 113 Groups...
#  #>  % finished: 10  20  30  40  50  60  70  80  90  100
#  #> Calculating graph cross linking in 113 Groups...
#  #>  % finished: 10  20  30  40  50  60  70  80  90  100
#  #> New number of ps-groups:  5080
#  #> xsAnnotate has now 5080 groups, instead of 113
#  #> Generating peak matrix for peak annotation!
#  #>
#  #> Calculating possible adducts in 5080 Groups...
#  #>  % finished: 10  20  30  40  50  60  70  80  90  100

## ---- warning = FALSE, message = FALSE, eval = FALSE---------------------
#  library(LOBSTAHS)
#  data(default.LOBdbase)
#  
#  default.LOBdbase$positive # default positive mode database
#  #>
#  #> A positive polarity "LOBdbase" object.
#  #>
#  #> Contains entries for 76455 possible adduct ions of 13578 unique parent compounds.
#  #>
#  #> Parent lipid types ( 4 ): DNPPE, IP_DAG, pigment, TAG
#  #> IP-DAG classes ( 8 ): DGCC, DGDG, DGTS_DGTA, PE, PG, PC, SQDG, MGDG
#  #> Pigments ( 22 ): Chl_a, 19prime_but_fuco, 19prime_hex_fuco, Allox, Alpha_carotene, Beta_carotenes, Chl_b, Chl_c2, Chl_c3, Chlide_a, Croco, Dd_Ddc, Dt, Echin, Fuco, Lut, Neox_Nos, Peri, Pheophytin_a, Pras, Viol, Zeax
#  #> Adducts ( 9 ): [M+2Na-H]+, [M+2Na+Cl]+, [M+C2H3Na2O2]+, [M+C4H10N3]+, [M+H]+, [M+K]+, [M+Na]+, [M+NH4]+, [M+NH4+ACN]+
#  #>
#  #> m/z range: 516.27208062-1396.1777983
#  #>
#  #> Ranges of chemical parameters represented in molecules other than pigments:
#  #>
#  #> Total number of acyl carbon atoms: 20-78
#  #> Total number of acyl carbon-carbon double bonds: 0-18
#  #> Number of additional oxygen atoms: 0-4
#  #>
#  #> Memory usage: 6.3 MB
#  
#  default.LOBdbase$negative # default negative mode database
#  #>
#  #> A negative polarity "LOBdbase" object.
#  #>
#  #> Contains entries for 60027 possible adduct ions of 11073 unique parent compounds.
#  #>
#  #> Parent lipid types ( 5 ): DNPPE, FFA, IP_DAG, pigment, PUA
#  #> IP-DAG classes ( 8 ): DGCC, DGDG, DGTS_DGTA, PE, PG, PC, SQDG, MGDG
#  #> Pigments ( 22 ): Chl_a, 19prime_but_fuco, 19prime_hex_fuco, Allox, Alpha_carotene, Beta_carotenes, Chl_b, Chl_c2, Chl_c3, Chlide_a, Croco, Dd_Ddc, Dt, Echin, Fuco, Lut, Neox_Nos, Peri, Pheophytin_a, Pras, Viol, Zeax
#  #> Adducts ( 11 ): [M-H]-, [M+2NaAc+Cl]-, [M+3Ac+2Na]-, [M+Cl]-, [M+HAc-H]-, [M+K-2H]-, [M+Na-2H]-, [M+Na+Cl-H]-, [M+NaAc-H]-, [M+NaAc+Cl]-, [M+NaAc+HAc-H]-
#  #>
#  #> m/z range: 95.05023848-1459.92498456
#  #>
#  #> Ranges of chemical parameters represented in molecules other than pigments:
#  #>
#  #> Total number of acyl carbon atoms: 6-52
#  #> Total number of acyl carbon-carbon double bonds: 0-12
#  #> Number of additional oxygen atoms: 0-4
#  #>
#  #> Memory usage: 4.97 MB

## ---- warning = FALSE, message = FALSE, eval = FALSE---------------------
#  data(default.acylRanges)
#  data(default.oxyRanges)
#  data(default.componentCompTable)
#  data(default.adductHierarchies)

## ---- eval = FALSE-------------------------------------------------------
#  LOBdb = generateLOBdbase(polarity = c("positive","negative"), gen.csv = FALSE,
#                   component.defs = NULL, AIH.defs = NULL, acyl.ranges = NULL,
#                   oxy.ranges = NULL)
#  

## ---- eval = FALSE-------------------------------------------------------
#  data(default.rt.windows)

## ---- eval = FALSE-------------------------------------------------------
#  myPtH2O2LOBSet = doLOBscreen(ptH2O2lipids$xsAnnotate, polarity = "positive",
#                               database = NULL, remove.iso = TRUE,
#                               rt.restrict =  TRUE, rt.windows = NULL,
#                               exclude.oddFA = TRUE, match.ppm = 2.5)

## ---- warning = FALSE, message = FALSE, eval = FALSE---------------------
#  ptH2O2lipids$LOBSet
#  #> A positive polarity "LOBSet" containing LC-MS peak data. Compound assignments and adduct ion hierarchy screening annotations applied to 16 samples using the "LOBSTAHS" package.
#  #>
#  #> Individual peaks: 21869
#  #> Peak groups: 1595
#  #> Compound assignments: 1969
#  #> m/z range: 551.425088845409-1269.09515435315
#  #>
#  #> Peak groups having possible regisomers: 556
#  #> Peak groups having possible structural functional isomers: 375
#  #> Peak groups having isobars indistinguishable within ppm matching tolerance: 84
#  #>
#  #> Restrictions applied prior to conducting adduct ion hierarchy screening: remove.iso, rt.restrict, exclude.oddFA
#  #>
#  #> Match tolerance used for database assignments: 2.5 ppm
#  #>
#  #> Memory usage: 1.26 MB

## ---- warning = FALSE, message = FALSE, eval = FALSE---------------------
#  ptH2O2lipids$LOBSet@LOBscreen.diagnostics
#  #>                     peakgroups  peaks assignments parent_compounds
#  #> initial                  18314 251545          NA               NA
#  #> post.remove.iso          12146 163938          NA               NA
#  #> initial.assignments       5077  67862       15929            14076
#  #> post.rt.restrict          4451  60070       13504            11779
#  #> post.exclude.oddFA        3871  52337        7458             6283
#  #> post.AIHscreen            1595  21869        2056             1969

## ---- warning = FALSE, message = FALSE, eval = FALSE---------------------
#  ptH2O2lipids$LOBSet@LOBisoID.diagnostics
#  #>                      peakgroups parent_compounds assignments features
#  #> C3r_regio.iso               556              352         750     7591
#  #> C3f_funct.struct.iso        375              577         752     5057
#  #> C3c_isobars                  84              162         195     1137

