.onLoad <- function(libname, pkgname)
{
#   suppressPackageStartupMessages(require(xcms))
#   suppressPackageStartupMessages(require(CAMERA))
#   require(methods)
#   require(utils)
}
